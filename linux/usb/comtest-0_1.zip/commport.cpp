// commport.cpp
//
// by Greg Kroah-Hartman <greg@kroah.com>
//
// This code is released into the public domain.  Do with it what you want.
//

#include <vcl.h>
#pragma hdrstop

#include <stdio.h>
#include "commport.hpp"

TCommPort::TCommPort (void) :
	portOpen	(false)
{
}


__fastcall TCommPort::~TCommPort()
{
	if (portOpen == true)
		ClosePort();
}


bool __fastcall TCommPort::OpenPort (const char *_commPortString)
{
	char	temp[15];

	if (portOpen == true)
		return false;
	if (_commPortString == NULL)
		return false;
	if (strlen(_commPortString)+1 > sizeof(commPortString))
		return false;

	strcpy (commPortString, _commPortString);

	sprintf (temp, "%sTX", commPortString);
	hcommEventTX = CreateEvent (NULL, false, false, temp);

	olTX.Offset	= 0;
	olTX.OffsetHigh	= 0;
	olTX.hEvent	= hcommEventTX;

	hcommId = CreateFile (commPortString,
			      GENERIC_READ | GENERIC_WRITE,
			      0,
			      NULL,
			      OPEN_EXISTING,
			      FILE_FLAG_OVERLAPPED,
			      NULL);
	
	if (hcommId == INVALID_HANDLE_VALUE) {
		MessageBox (NULL,"Could not open COM port.", "Invalid Comm Handle", MB_OK);
		return false;
	}

	portOpen = true;
	return true;
}


bool __fastcall TCommPort::ChangeSettings (const int	baudRate,
					   const char	parity,
					   const int	dataBits)
{
	DCB		dcb;
	COMMTIMEOUTS	cto;
	DWORD		EvMask;
	OSVERSIONINFO	ver;

	if (portOpen == false)
		return false;

	// get the current com port state
	if (!GetCommState(hcommId, &dcb)) {
		MessageBox (NULL, "Could not change settings", "Error getting comm state.", MB_OK);
		return false;
	}

	dcb.BaudRate = (DWORD)baudRate;
	dcb.ByteSize = (BYTE)dataBits;

	switch (tolower(parity)) {
		case 'n':	dcb.Parity = NOPARITY;		break;
		case 'e':	dcb.Parity = EVENPARITY;	break;
		case 'o':	dcb.Parity = ODDPARITY;		break;
		case 'm':	dcb.Parity = MARKPARITY;	break;
		default:
			MessageBox (NULL, "Could not change settings", "Invalid Parity setting", MB_OK);
			return false;
	}

	dcb.StopBits		= ONESTOPBIT;
	dcb.fOutX		= FALSE;
	dcb.fInX		 = FALSE;
	dcb.fOutxCtsFlow	= FALSE;
	dcb.fOutxDsrFlow	= FALSE;
	dcb.fDtrControl		= DTR_CONTROL_DISABLE;
	dcb.fDsrSensitivity	= FALSE;
	dcb.fRtsControl		= RTS_CONTROL_ENABLE;

	if (!SetCommState(hcommId, &dcb)) {
		MessageBox (NULL, "Could not change settings", "Error setting comm state.", MB_OK);
		return false;
	}

	return true;
}


bool __fastcall TCommPort::ClosePort (void)
{
	if (!portOpen)
		return false;
	PurgeComm (hcommId, PURGE_TXABORT | PURGE_RXABORT);
	CloseHandle (hcommEventTX);
	CloseHandle (hcommId);
	portOpen = false;
	return true;
}


int __fastcall TCommPort::WriteData (unsigned char *data, int length)
{
  volatile bool Result;
  DWORD bytesSent;

  Result = WriteFile (hcommId, data, (DWORD)length, &bytesSent, &olTX);
  WaitForSingleObject (hcommEventTX, INFINITE);
  return bytesSent;
}


