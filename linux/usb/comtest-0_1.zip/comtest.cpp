//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("comtest.res");
USEFORM("mainform.cpp", Form1);
USEUNIT("commport.cpp");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	try
	{
		Application->Initialize();
		Application->Title = "Com Port Test";
		Application->CreateForm(__classid(TForm1), &Form1);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	return 0;
}
//---------------------------------------------------------------------------
