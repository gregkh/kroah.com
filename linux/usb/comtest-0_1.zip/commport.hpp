// commport.hpp
//
// by Greg Kroah-Hartman <greg@kroah.com>
//
// This code is released into the public domain.  Do with it what you want.
//

#if !defined(__COMMPORT_HPP)
#define __COMMPORT_HPP

class TCommPort {
public:
	TCommPort		();
	__fastcall ~TCommPort	(void);

	bool __fastcall OpenPort	(const char *commPortString = NULL);
	bool __fastcall ClosePort	(void);

	bool __fastcall	ChangeSettings	(const int	baudRate,
					 const char     parity,
					 const int      dataBits);
	int __fastcall	WriteData	(unsigned char *data, int length);
	bool __fastcall	IsOpen		(void) { return portOpen; }

private:
	bool		portOpen;
	char		commPortString[10];
	HANDLE		hcommId;
	HANDLE		hcommEventTX;
	DWORD		timeOutms;
	OVERLAPPED	olTX;
};

#endif

