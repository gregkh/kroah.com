// mainform.cpp
//
// by Greg Kroah-Hartman <greg@kroah.com>
//
// This code is released into the public domain.  Do with it what you want.
//

//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "commport.hpp"
#include "mainform.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner), commPort (NULL)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormDestroy(TObject *Sender)
{
	if (commPort != NULL) {
		commPort->ClosePort();
        	delete commPort;
		commPort = NULL;
        }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
	commPort = new TCommPort;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::BitBtnCloseClick(TObject *Sender)
{
	Application->Terminate();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonOpenPortClick(TObject *Sender)
{
	char *string;

        string = ComboBoxPort->Text.c_str();
	if (strlen(string) == 0) {
        	::MessageBox (NULL, "must select a port first", "error", MB_OK);
                return;
        }
        
	// hack around odd bug in the vcl
        string[strlen(string)-1] = 0x00;

	if (commPort->IsOpen() == true) {
        	::MessageBox (NULL, "port is already open", "error", MB_OK);
                return;
        }

        if (commPort->OpenPort (string) == false) {
        	::MessageBox (NULL, "port open failed", "error", MB_OK);
                return;
        }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonClosePortClick(TObject *Sender)
{
	if (commPort->IsOpen() == false) {	
        	::MessageBox (NULL, "port is not open", "error", MB_OK);
                return;
        }
        commPort->ClosePort();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonSendDataClick(TObject *Sender)
{
	char	*string;
        int	length;

	if (commPort->IsOpen() == false) {	
        	::MessageBox (NULL, "port is not open", "error", MB_OK);
                return;
        }

        string = EditData->Text.c_str();
        length = strlen(string);
        
	commPort->WriteData (string, length);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonSetClick(TObject *Sender)
{
	int	baud;
	char	parity;
	int	databits;

	if (commPort->IsOpen() == false) {	
        	::MessageBox (NULL, "port is not open", "error", MB_OK);
                return;
        }

	switch (RadioGroupBaudRate->ItemIndex) {
		case 0:		baud = 110;	break;
		case 1:		baud = 300;	break;
		case 2:		baud = 600;	break;
		case 3:		baud = 1200;	break;
		case 4:		baud = 2400;	break;
		case 5:		baud = 4800;	break;
		case 6:		baud = 9600;	break;
		case 7:		baud = 14400;	break;
		case 8:		baud = 19200;	break;
		case 9:		baud = 38400;	break;
		case 10:	baud = 56000;	break;
		case 11:	baud = 57600;	break;
		case 12:	baud = 115200;	break;
		case 13:	baud = 128000;	break;
		case 14:	baud = 256000;	break;
		default:	::MessageBox (NULL, "select a baud rate", "error", MB_OK); return;
	}

	switch (RadioGroupByteSize->ItemIndex) {
		case 0:		databits = 5;	break;
		case 1:		databits = 6;	break;
		case 2:		databits = 7;	break;
		case 3:		databits = 8;	break;
		default:	::MessageBox (NULL, "select a byte size", "error", MB_OK); return;
	}

	switch (RadioGroupParity->ItemIndex) {
		case 0:		parity = 'e';	break;
		case 1:		parity = 'm';	break;
		case 2:		parity = 'n';	break;
	        case 3:		parity = 'o';	break;
		default:	::MessageBox (NULL, "select a parity setting", "error", MB_OK); return;
	}

	commPort->ChangeSettings (baud, parity, databits);
}
//---------------------------------------------------------------------------

