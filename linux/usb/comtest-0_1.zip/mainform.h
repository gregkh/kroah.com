// mainform.h
//
// by Greg Kroah-Hartman <greg@kroah.com>
//
// This code is released into the public domain.  Do with it what you want.
//
//---------------------------------------------------------------------------

#ifndef mainformH
#define mainformH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>

class TCommPort;

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TBitBtn *BitBtnClose;
	TComboBox *ComboBoxPort;
	TLabel *Label1;
	TButton *ButtonOpenPort;
	TButton *ButtonClosePort;
	TRadioGroup *RadioGroupBaudRate;
	TPanel *Panel1;
	TRadioGroup *RadioGroupParity;
	TRadioGroup *RadioGroupCTS;
	TRadioGroup *RadioGroupDSR;
	TRadioGroup *RadioGroupDTR;
	TRadioGroup *RadioGroupByteSize;
	TButton *ButtonSet;
	TEdit *EditData;
	TLabel *Label2;
	TButton *ButtonSendData;
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall BitBtnCloseClick(TObject *Sender);
	void __fastcall ButtonOpenPortClick(TObject *Sender);
	void __fastcall ButtonClosePortClick(TObject *Sender);
	void __fastcall ButtonSendDataClick(TObject *Sender);
	void __fastcall ButtonSetClick(TObject *Sender);
private:	// User declarations
	TCommPort	*commPort;
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
