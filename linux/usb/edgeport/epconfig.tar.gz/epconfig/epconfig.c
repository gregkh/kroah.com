/***********************************************************
 * Edgeport Configuration Utility
 *
 * Copyright(c) 2000 Inside Out Networks, All rights reserved.
 *
 *
 * Version history:
 *
 * 0.5 (06/29/00) David Iacovelli
 *   Fixed date for Y2K
 *
 * 0.4 (05/01/00) David Iacovelli
 *  Remove printf for daemon
 *  Only update file if something has changed
 *
 * 0.3 (04/26/00) David Iacovelli
 *  Add comments
 *
 * 0.2 (04/24/00) David Iacovelli
 *  Use only the /proc/edgeport interface for config/status
 *
 * 0.1 (04/24/00) David Iacovelli
 *  Initial version with all functionality
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>  // needed for access
#include <errno.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <signal.h>
#include "io_edgeport.h"

#define VERSION "1.0"
#define DEFAULT_PATH "/etc/epconfig.rc"
//***********************************************************
//*															*
//*	 Definitions											*
//*															*
//***********************************************************
struct CommTable
{
	int 			 NumEntries;
	struct comMapper Entry[MAX_EDGEPORTS];
};


//***********************************************************
//*															*
//*	 Global Variables										*
//*															*
//***********************************************************
static int  Listing		   	= FALSE;
static int  Loopforever	   	= FALSE;
static char ConfigFile[64];


// From Configuration file
struct CommTable FileTable;
int FileVar_MappingBaseOnPath;

// From Edgeport driver
struct CommTable DriverTable;
int DriverVar_MappingBaseOnPath;

	
//***********************************************************
//*															*
//*	 Static Routines										*
//*															*
//***********************************************************
static void StrBlk2Str		(char *pString, PSTRING_BLOCK pStrBlock, int Index);
static int  OpenConfig 		(void);
static void epconfigExit	(int s);
static void ListShort		(void);
static void ListCurrent		(void);
static void ListVerbose		(void);
static void	ParseFile		(void);
static void GetConfiguration(void);
static void UpdateFile		(void);
static void UpdateEdgeport	(void);
static int  MergeConfig		(void);
static int  AddEntry		(struct CommTable *Table, struct comMapper *Entry, int Overwrite);
static void DumpTable		(struct CommTable *Table);

static char ConfigDevice[] = EDGEPORT_CONFIG_DEVICE;

//***********************************************************
//***********************************************************

int main( int argc, char *argv[] )
{
	int opt;

	DriverTable.NumEntries=0;
	FileTable.NumEntries = 0;
	FileVar_MappingBaseOnPath = 0;

	strcpy(ConfigFile, DEFAULT_PATH);

	// Parse command line
	while ((opt = getopt (argc, argv, "dlvcf:")) != -1)
	{	
		switch(opt)
		{
		case 'f':
			strcpy(ConfigFile, optarg);
			break;

		case 'd':
			Loopforever = TRUE;
			break;

		case 'v':
			Listing = TRUE;
			ListVerbose();
			break;
			
		case 'l':
			Listing = TRUE;
			ListShort();
			break;

		case 'c':
			Listing = TRUE;
			ListCurrent();
			break;

		default:
			printf("epconfig - Edgeport configuration/monitor utility Version %s\n", VERSION);
			printf("Copyright (c) 2000 Inside Out Networks\n\n");
			printf("Usage epconf -f <config file> -d -v -l -c\n");
			printf("             -f -- configuration file path (default: %s\n", DEFAULT_PATH);
			printf("             -d -- run forever\n");
			printf("             -l	-- list driver configuration table\n");
			printf("             -c	-- list currently attached devices\n");
			printf("             -v	-- list currently attached devices (verbose)\n");
			exit(1);
		}
	}


	// Do not update if one of the output switches is selected
	if (Listing)
	{
		return 0;
	}


	signal(SIGKILL, epconfigExit );
	signal(SIGHUP , epconfigExit );
	signal(SIGQUIT, epconfigExit );
	signal(SIGTERM, epconfigExit );

	// Loop forever 
	do
	{
		ParseFile();
		//printf("File Configuration Table:\n");
		//DumpTable(&FileTable);

		GetConfiguration();
		//printf("Driver Configuration Table:\n");
		//DumpTable(&DriverTable);
		
		if (MergeConfig())
		{
			UpdateFile();
		}
		UpdateEdgeport();

		if (Loopforever)
		{
			sleep(20);
		}
	} while ( Loopforever );	
	return 0;
}


/********************************************************
 * epconfigExit()  - Called when we get a termination 	*
 *					 signal. Update file and exit		*
 *														*
 *														*
 ********************************************************/
void epconfigExit(int s)
{
	printf("\nepconfig terminating\n");

	ParseFile();
	printf("File Configuration Table:\n");
	DumpTable(&FileTable);

	GetConfiguration();
	printf("Driver Configuration Table:\n");
	DumpTable(&DriverTable);

	if (MergeConfig())
	{
		UpdateFile();
	}
	exit(0);
}


/********************************************************
 *	AddEntry()	- 	Add a new entry to one of the tables*
 *				  	FileTable or DriverTable.  			*
 *					If Overwrite is set then we will 	*
 *					replace an existing entry.			*
 * Return true if an entry was updated or added			*
 ********************************************************/
int AddEntry(
	struct CommTable *Table, 
	struct comMapper *Entry,
	int    Overwrite)
{
	int i;

	// Check for an existing entry
	for(i=0; i<	Table->NumEntries; i++)
	{
		if (strcmp(Entry->SerialNumber, Table->Entry[i].SerialNumber) == 0)
		{
			// Do we want to replace it?
			if (Overwrite)
			{
				Table->Entry[i] =  *Entry;
				return TRUE;
			}
			return FALSE;
		}
	}

	//printf("adding %d, %s\n",  Table->NumEntries,  Entry->SerialNumber);
	
	// Add new entry to end of table
	// Note that once an edgeport is seen it can not be deleted from the 
	// registry
	Table->Entry[Table->NumEntries] = *Entry;
	Table->NumEntries++;
	return TRUE;
}



/********************************************************
 * DumpTable	- 	Dump table entries (debug only)		*
 *														*
 ********************************************************/
void DumpTable(
	struct CommTable *Table
	)
{
	int i,j;
	char OutLine[80];
	char *pOutLine;
	
	for(i=0; i<	Table->NumEntries; i++)
	{
		pOutLine = OutLine;
		pOutLine += sprintf(pOutLine, "%s:",Table->Entry[i].SerialNumber);
		for (j=0; j < Table->Entry[i].numPorts; j++)
		{
			pOutLine += sprintf(pOutLine, "%d,",Table->Entry[i].Original[j]);
		}
		*--pOutLine = '\0';
		printf("%s\n", OutLine);
	}
}


/********************************************************
 *MergeConfig											*
 *														*
 *  Add any entries read from the driver that are not 	*
 *  currently in the FileTable to the FileTable.		*
 *														*
 *														*
 ********************************************************/
static int MergeConfig(void)
{
	int i;
	struct comMapper *DriverEntry;
	int updated = FALSE;

	// Update the FileTable from the Driver
	for(i=0; i<	DriverTable.NumEntries; i++)
	{
		DriverEntry = &DriverTable.Entry[i];
		if (AddEntry(&FileTable, DriverEntry, FALSE))
		{
			updated = TRUE;
		}
	}
	return updated;
}


/********************************************************
 *	UpdateFile:	Recreate the file from the data in saved*
 *				in the DriverTable and FileTable 		*
 *				structures								*
 *														*
 ********************************************************/
static void UpdateFile(void)
{
	FILE *handle;
	int i;
	int j;
	char OutLine[80];
	char *pOutLine;


	handle = fopen (ConfigFile, "w");
	if (!handle)
	{
		printf("Can't create configuration file %s\n", ConfigFile);
		exit(1);
	}

	fprintf(handle, "#     Edgeport Configuration file [epconf.rc]\n");
	fprintf(handle, "#\n");
	fprintf(handle, "#### Variables:\n");
	fprintf(handle, "#\n");
	fprintf(handle, "!ComMappingBasedOnUSBPort:%1d\n", 	FileVar_MappingBaseOnPath);
	fprintf(handle, "#\n");
	fprintf(handle, "#\n");
	fprintf(handle, "#### Edgeport serial numbers and port assigments\n");
	fprintf(handle, "#\n");


	for(i=0; i<	FileTable.NumEntries; i++)
	{
		pOutLine = OutLine;
		pOutLine += sprintf(pOutLine, "%s:",FileTable.Entry[i].SerialNumber);
		for (j=0; j < FileTable.Entry[i].numPorts; j++)
		{
			pOutLine += sprintf(pOutLine, "%d,",FileTable.Entry[i].Original[j]);
		}
		*--pOutLine = '\0';
		fprintf(handle, "%s\n", OutLine);
	}
	fprintf(handle, "#\n");

	fclose (handle);
}



/********************************************************
 *	ParseFile:	Read the configuration file and store	*
 *				the information in the FileTable		*
 *														*
 ********************************************************/
static void	ParseFile()
{
	FILE *			 handle;
	char 			 ParseLine[128];
	int 			 Len;
	int 			 LineNum = 0;
	char 			 Variable[32];
	int 			 Value;
	char *			 p1;
	char *			 p2;
	char *			 p3;
	struct comMapper Entry;

	FileTable.NumEntries=0;
	FileVar_MappingBaseOnPath = 0;				

	handle = fopen (ConfigFile, "r");
	if (!handle)
	{
		return;
	}

	// Parse each line in the file
	while(fgets(ParseLine, 128, handle))
	{
		LineNum++;
		Len = strlen(ParseLine);
		if (Len < 2)
			continue;
		if (ParseLine[Len-1] !='\n')
		{
			printf("Error line too long on line %d\n", 	LineNum);
			exit(1);
		}
		
		switch (*ParseLine)
		{
		case '#':
			break;

		case '!':
			p1=ParseLine + 1;			
			p2=strchr(p1, ':');
			if (!p2)
			{
				printf("Syntax error on line %d ':' not found\n", 	LineNum);
				exit(1);
			}
			*p2++=0;
			sscanf(p1, "%s", Variable);
			sscanf(p2, "%d", &Value);

			if (strcmp(Variable, "ComMappingBasedOnUSBPort") == 0)
			{
				FileVar_MappingBaseOnPath = Value;				
				//printf("Variable = [%s] set to %d\n", Variable, Value);
			}
			else
			{
				printf("Error on line %d '%s' not found\n", LineNum, Variable);
				exit(1);
			}
			break;


		default:
			memset(&Entry, 0, sizeof(Entry));
			p1 = ParseLine;
			p2=strchr(p1, ':');
			if (!p2)
			{
				printf("Syntax error on line %d ':' not found\n", 	LineNum);
				exit(1);
			}
			*p2++=0;
			sscanf(p1, "%s", Variable);
			if (strlen(Variable) > MAX_SERIALNUMBER_LEN)
			{
				printf("Serial Number too long on line %d\n", 	LineNum);
				exit(1);
			}
			strcpy(Entry.SerialNumber, Variable);
			Entry.numPorts = 0;

			p3 = strchr(p2, '\n');
			if (!p3)
			{
				printf("Syntax error on line %d end of line not found\n", LineNum);
				exit(1);
			}
			*p3=0;
			
			while (*p2)
			{
				// Convert to integer (Parse string)
				Entry.Original[Entry.numPorts++] = atoi(p2);

				while(*p2 && (*p2 != ','))
					p2++;
				while(*p2 && (*p2 == ',' || *p2 == ' '))
					p2++;
			}
			AddEntry(&FileTable, &Entry, TRUE);
		}
	}
	fclose(handle);
}

/********************************************************
 * NotCurentInDriver:	Check if a serial number needs	*
 *						to be updated in the driver		*
 *														*
 ********************************************************/
int NotCurentInDriver(struct comMapper *Entry)
{
	int i;
	int j;
	int Match;

	for(i=0; i< DriverTable.NumEntries; i++)
	{
		if ( (strcmp(Entry->SerialNumber, DriverTable.Entry[i].SerialNumber) == 0) &&
			 (Entry->numPorts == DriverTable.Entry[i].numPorts))
		{
			Match = 1;
			for (j=0; j<Entry->numPorts; j++)
		   	{
				if (Entry->Original[j] != DriverTable.Entry[i].Original[j])
				{
					Match = 0;
					break;
				}
		   	}
			if (Match)
			{
				return 0;
			}
		}
	}
	return 1;
}

/********************************************************
 * UpdateEdgeport:	Update configuration in the edgeport*
 *														*
 ********************************************************/
static void UpdateEdgeport(void)
{
	int	hPort;
	int i;
	struct procWrite WriteCmd;

	hPort = OpenConfig();

	if (hPort < 0)
	{
		printf("Edgeport Drivers not loaded\n");
		return;
	}

	if (DriverVar_MappingBaseOnPath	 !=  FileVar_MappingBaseOnPath)
	{
		// update variable
		WriteCmd.Command = PROC_SET_COM_MAPPING;
		WriteCmd.u.ComMappingBasedOnUSBPort = FileVar_MappingBaseOnPath;
		write( hPort, &WriteCmd, sizeof(struct procWrite));
	}

	for(i=0; i<	FileTable.NumEntries; i++)
	{
		// only update if this info is not currently in the edgeport
		if (NotCurentInDriver(&FileTable.Entry[i]))
		{
			WriteCmd.Command = PROC_SET_COM_ENTRY;
			WriteCmd.u.Entry = FileTable.Entry[i];
			write( hPort, &WriteCmd, sizeof(struct procWrite));
		}
	}
	close (hPort);
}

/********************************************************
 * GetConfiguration:									*
 *		Read the configuration information from the		*
 *		edgeport driver.								*
 *														*
 ********************************************************/
static void GetConfiguration(void)
{
	int	hPort;
	int ep;
	int	status;
	struct comMapper Entry;

	hPort = OpenConfig();

	if (hPort < 0)
	{
		printf("Edgeport Drivers not loaded\n");
		return;
	}

	lseek(hPort, PROC_READ_SETUP(PROC_GET_MAPPING_TO_PATH,0), 0);
	read( hPort, &DriverVar_MappingBaseOnPath, sizeof(int) );

	// read the edgeport configuration file
	for(ep=0; ep < MAX_EDGEPORTS; ep++)
	{
		lseek(hPort, PROC_READ_SETUP(PROC_GET_COM_ENTRY, ep), 0);
	    status = read( hPort, &Entry, sizeof(Entry) );
		if (status == sizeof(Entry))
		{
			AddEntry(&DriverTable, &Entry, TRUE);
		}
	}
	close (hPort);
}


/********************************************************
 * ListShort: 	Get a short listing of the configuration* 
 *				information which is not necessarly 	*
 *				the current port assignment				*
 *														*
 ********************************************************/
static void ListShort(void)
{
	int	hPort;
	int i;
	int ep;
	int	status;
	char OutLine[80];
	char *pOutLine;
	struct comMapper Entry;

	hPort = OpenConfig();

	if (hPort < 0)
	{
		printf("Edgeport Drivers not loaded\n");
		return;
	}

	lseek(hPort, PROC_READ_SETUP(PROC_GET_MAPPING_TO_PATH,0), 0);
	
	status = read( hPort, &i, sizeof(int) );

	if (status == sizeof(int))
	{
		printf("!ComMappingBasedOnUSBPort:%1d\n", i);
	}

	for(ep=0; ep < MAX_EDGEPORTS; ep++)
	{
		lseek(hPort, PROC_READ_SETUP(PROC_GET_COM_ENTRY, ep), 0);
	    status = read( hPort, &Entry, sizeof(Entry) );
		if (status == sizeof(Entry))
		{
			pOutLine = OutLine;
			pOutLine += sprintf(pOutLine, "%s:",Entry.SerialNumber);
			for (i=0; i < Entry.numPorts; i++)
			{
				pOutLine += sprintf(pOutLine, "%d,",Entry.Original[i]);
			}
			*--pOutLine = '\0';
			printf("%s\n", OutLine);
		}
	}
	close (hPort);
}

/********************************************************
 * ListCurrent:	Display current port assignemnts		*
 *														*
 ********************************************************/
static void ListCurrent(void)
{
	int	hPort;
	int i;
	int ep;
	int	status;
	char OutLine[80];
	char *pOutLine;
	struct comMapper Entry;
	int numAttached = 0;

	hPort = OpenConfig();

	if (hPort < 0)
	{
		printf("Edgeport Drivers not loaded\n");
		return;
	}

	printf("Edgeports currently attached:\n");
	for(ep=0; ep < MAX_EDGEPORTS; ep++)
	{
		lseek(hPort, PROC_READ_SETUP(PROC_GET_CURRENT_COM_MAPPING, ep), 0);
	    status = read( hPort, &Entry, sizeof(Entry) );
		if (status == sizeof(Entry))
		{
			numAttached++;
			pOutLine = OutLine;
			pOutLine += sprintf(pOutLine, "%s:",Entry.SerialNumber);
			for (i=0; i < Entry.numPorts; i++)
			{
				pOutLine += sprintf(pOutLine, "%d,",Entry.Port[i]);
			}
			*--pOutLine = '\0';
			printf("%s\n", OutLine);
		}
	}
	if (!numAttached)
	{
		printf(" - NONE -\n");
	}
	close (hPort);
}

/********************************************************
 * ListVerbose:	List current port assignments and other *
 *				information about the attached edgeports*
 *														*
 ********************************************************/
static void ListVerbose(void)
{
	int ep;
	int	hPort;
	int	status;
	struct comMapper Map;
	int j;
	char OutLine[80];
	char Buffer[256];
	PSTRING_BLOCK pSBlock = (PSTRING_BLOCK)Buffer;
	PRODUCT_INFO ProductInfo;

	hPort = OpenConfig();

	if (hPort == -1) 
	{
		printf("Edgeport Drivers not loaded\n");
		return;
	}

	for(ep =0; ep < MAX_EDGEPORTS; ep++)
	{

		lseek(hPort, PROC_READ_SETUP(PROC_GET_CURRENT_COM_MAPPING, ep), 0);
	    status = read( hPort, &Map, sizeof(Map) );
		if (status == sizeof(Map))
		{
			printf("\nSerial Number: 	%s\n", Map.SerialNumber);
			printf("Port Mapping to Device name:\n");
				
				printf("      \tConfig\tCurrent\n");

			for (j=0; j < Map.numPorts; j++)
			{
				printf("Port%d\t %3d  \t %3d   \n",j+1, Map.Original[j], Map.Port[j]);
			}
			printf("\n");
		
		}

		lseek(hPort, PROC_READ_SETUP(PROC_GET_PRODUCT_INFO, ep), 0);
	    status = read( hPort, &ProductInfo, sizeof(ProductInfo) );
		if (status == sizeof(ProductInfo))
		{
				printf( "Product Id      : 0x%X\n"	, ProductInfo.ProductId);
				printf( "Number of Ports : %d\n"	, ProductInfo.NumPorts);

			if (ProductInfo.RomSize)
				printf( "Rom Size        : %d\n"	, ProductInfo.RomSize);

			if (ProductInfo.RamSize)
				printf( "Ram Size        : %d\n"	, ProductInfo.RamSize);

			if (ProductInfo.CpuRev)
				printf( "Cpu Revision    : %d\n"	, ProductInfo.CpuRev);	

			if (ProductInfo.BoardRev)
				printf( "Board Revision  : %d\n"	, ProductInfo.BoardRev);


			if (ProductInfo.ManufactureDescDate[0])
				printf( "Desciptor Date  : %02d/%02d/%4d\n",	
													ProductInfo.ManufactureDescDate[0],
									 	  			ProductInfo.ManufactureDescDate[1],
													ProductInfo.ManufactureDescDate[2]+1900);
			
			if (ProductInfo.FirmwareMajorVersion)
				printf( "Download Version: %d.%d.%d\n",	
													ProductInfo.FirmwareMajorVersion, 
									 				ProductInfo.FirmwareMinorVersion, 
									 				ProductInfo.FirmwareBuildNumber);
			if (ProductInfo.BootMajorVersion)
				printf( "Boot Version    : %d.%d.%d\n", 
													ProductInfo.BootMajorVersion, 
													ProductInfo.BootMinorVersion, 
													ProductInfo.BootBuildNumber);
		}

		lseek(hPort, PROC_READ_SETUP(PROC_GET_STRINGS, ep), 0);
	    status = read( hPort, pSBlock, sizeof(Buffer) );
		if (status > 0)
		{
			StrBlk2Str(OutLine, pSBlock, EDGESTRING_MANUFNAME);
			if (*OutLine != '\0') printf( "Manufacturer    : %s\n",  OutLine);

			StrBlk2Str(OutLine, pSBlock, EDGESTRING_PRODNAME);
			if (*OutLine != '\0') printf( "Product name    : %s\n",  OutLine);
		
			StrBlk2Str(OutLine, pSBlock, EDGESTRING_SERIALNUM);
			if (*OutLine != '\0') printf( "Identifier      : %s\n",  OutLine);

			StrBlk2Str(OutLine, pSBlock, EDGESTRING_ORIGSERIALNUM);
			if (*OutLine != '\0') printf( "Serial number   : %s\n",  OutLine);

			StrBlk2Str(OutLine, pSBlock, EDGESTRING_ASSEMNUM);
			if (*OutLine != '\0') printf( "Part Number     : %s\n",  OutLine);

			StrBlk2Str(OutLine, pSBlock, EDGESTRING_MANUFDATE);
			if (*OutLine != '\0') printf( "Manufacture date: %s\n",  OutLine);
		}
	}
	close (hPort);
}


/********************************************************
 *	OpenConfig:	open the device for configuration 		*
 *				/proc/egeport							*
 *														*
 ********************************************************/
static int OpenConfig (void)
{
	int		fd;

	if ((fd = open (ConfigDevice, O_RDWR)) < 0) 
	{
		return(-1);
	}

	return(fd);						   
}

/*==================================================================
 * void StrBlk2Str(PCHAR pString, PSTRING_BLOCK pStrBlock, int Index)
 *
 * 	Get indexed string from string block and convert from
 *  Double wide to ASCIZ
 *
 * Index is 1 based
 */
void StrBlk2Str(char *pString, PSTRING_BLOCK pStrBlock, int Index)
{
	int 	i;
	PWCHAR	pStart;
	*pString = 0;

	// make sure that the string index is within string block
	if (pStrBlock->NumStrings < Index)
		return;

	// adjust index for 1 based
	Index--;


	// Initilaize to string 1
	pStart =pStrBlock->Strings;

	// Search for string in block
	for (i=0; i<Index; i++)
	{
		while(*pStart)
			pStart++;
		pStart++;
	}

	// convert to asciz
	while(*pStart)
	{
		*pString++ = (char)*pStart++;
	}
	// Null terminate
	*pString = 0;
}
