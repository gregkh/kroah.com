extern void ShowMessage (gchar *title, gchar *message);
